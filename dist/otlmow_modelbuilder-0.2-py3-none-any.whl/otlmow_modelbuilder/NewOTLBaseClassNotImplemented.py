class NewOTLBaseClassNotImplemented(NotImplementedError):
    pass
