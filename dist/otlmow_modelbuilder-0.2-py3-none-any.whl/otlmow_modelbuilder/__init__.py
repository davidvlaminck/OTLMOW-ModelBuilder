class Datatypes:
    pass